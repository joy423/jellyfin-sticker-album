using MediaBrowser.Model.Plugins;

namespace JellyfinStickerAlbum.Configuration;

/// <summary>
/// Configuration for the Jellyfin Sticker Album Plugin.
/// </summary>
public class PluginConfiguration : BasePluginConfiguration
{
    /// <summary>
    /// Gets or sets the watch duration in minutes required to earn a sticker.
    /// </summary>
    public int WatchDurationMinutes { get; set; } = 15;

    /// <summary>
    /// Gets or sets the total number of sticker slots in the album.
    /// </summary>
    public int TotalStickerSlots { get; set; } = 20;

    /// <summary>
    /// Gets or sets a value indicating whether sound effects are enabled.
    /// </summary>
    public bool EnableSoundEffects { get; set; } = true;

    /// <summary>
    /// Gets or sets the probability of earning a Legendary sticker (0.0 - 1.0).
    /// </summary>
    public double LegendaryProbability { get; set; } = 0.02;

    /// <summary>
    /// Gets or sets the probability of earning an Epic sticker (0.0 - 1.0).
    /// </summary>
    public double EpicProbability { get; set; } = 0.08;

    /// <summary>
    /// Gets or sets the probability of earning a Premium sticker (0.0 - 1.0).
    /// </summary>
    public double PremiumProbability { get; set; } = 0.30;
}
