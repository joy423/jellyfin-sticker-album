namespace JellyfinStickerAlbum.Models;

/// <summary>Represents one earned sticker.</summary>
public class Sticker
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Rarity { get; set; } = "Normal";
    public string Emoji { get; set; } = "⭐";
    public DateTime EarnedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Persisted album data for a single user.</summary>
public class StickerAlbumData
{
    public string UserId { get; set; } = string.Empty;
    public List<Sticker> Stickers { get; set; } = new();
    public double TotalWatchMinutes { get; set; }
    public DateTime LastUpdated { get; set; } = DateTime.UtcNow;
}
