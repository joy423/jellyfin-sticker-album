using System.Net.Mime;
using System.Text.Json;
using JellyfinStickerAlbum.Models;
using MediaBrowser.Controller.Authentication;
using MediaBrowser.Controller.Library;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace JellyfinStickerAlbum.Controllers;

/// <summary>
/// REST API controller for the Sticker Album plugin.
/// All endpoints are accessible by authenticated users.
/// </summary>
[ApiController]
[Authorize]
[Route("api/plugins/stickeralbum")]
[Produces(MediaTypeNames.Application.Json)]
public class StickerController : ControllerBase
{
    // ─── Static emoji pool used when generating stickers ────────────────────
    private static readonly string[] StickerEmojis =
    {
        "🎬", "🎭", "🎥", "🎞️", "📽️", "🍿", "🎮", "🎯",
        "🏆", "⭐", "🌟", "💫", "✨", "🔥", "💎", "🦄",
        "🎸", "🎺", "🎻", "🥁"
    };

    private static readonly string[] StickerNames =
    {
        "Film-Fan",     "Drama-König",  "Kameramann", "Regisseur",  "Produzent",
        "Popcorn-Fan",  "Gamer",        "Scharfschütze", "Champion", "Stern",
        "Superstar",    "Zauberer",     "Glitzer",    "Feuerspucker", "Edelstein",
        "Einhörner",    "Rockstar",     "Trompeter",  "Geiger",     "Drummer"
    };

    // ─── In-memory store (key: userId → album data) ──────────────────────────
    // In a production plugin you would persist this to a JSON file under
    // applicationPaths.DataPath or to SQLite via the Jellyfin database.
    private static readonly Dictionary<string, StickerAlbumData> Albums = new();
    private static readonly object Lock = new();

    private readonly ILogger<StickerController> _logger;

    public StickerController(ILogger<StickerController> logger)
    {
        _logger = logger;
    }

    // ─── GET /api/plugins/stickeralbum/album/{userId} ───────────────────────

    /// <summary>Returns the sticker album for the given user.</summary>
    [HttpGet("album/{userId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ActionResult<StickerAlbumData> GetAlbum(string userId)
    {
        lock (Lock)
        {
            if (!Albums.TryGetValue(userId, out var album))
            {
                album = new StickerAlbumData { UserId = userId };
                Albums[userId] = album;
            }

            return Ok(album);
        }
    }

    // ─── POST /api/plugins/stickeralbum/album/{userId} ──────────────────────

    /// <summary>Overwrites (saves) the sticker album for the given user.</summary>
    [HttpPost("album/{userId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public IActionResult SaveAlbum(string userId, [FromBody] StickerAlbumData data)
    {
        data.UserId = userId;
        data.LastUpdated = DateTime.UtcNow;

        lock (Lock)
        {
            Albums[userId] = data;
        }

        _logger.LogInformation("[StickerAlbum] Saved album for user {UserId} ({Count} stickers)",
            userId, data.Stickers.Count);

        return NoContent();
    }

    // ─── POST /api/plugins/stickeralbum/earn/{userId} ───────────────────────

    /// <summary>
    /// Awards a randomly generated sticker to the user.
    /// The rarity is determined by the current plugin configuration.
    /// </summary>
    [HttpPost("earn/{userId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ActionResult<Sticker> EarnSticker(string userId)
    {
        var config = Plugin.Instance?.Configuration;
        var rng    = new Random();

        // Determine rarity
        var roll    = rng.NextDouble();
        string rarity;

        if (config != null && roll < config.LegendaryProbability)
            rarity = "Legendär";
        else if (config != null && roll < config.LegendaryProbability + config.EpicProbability)
            rarity = "Episch";
        else if (config != null && roll < config.LegendaryProbability + config.EpicProbability + config.PremiumProbability)
            rarity = "Premium";
        else
            rarity = "Normal";

        // Pick a random slot (index into the 20-item pool)
        var idx = rng.Next(StickerEmojis.Length);

        var sticker = new Sticker
        {
            Id      = idx + 1,
            Name    = StickerNames[idx],
            Emoji   = StickerEmojis[idx],
            Rarity  = rarity,
            EarnedAt = DateTime.UtcNow
        };

        lock (Lock)
        {
            if (!Albums.TryGetValue(userId, out var album))
            {
                album = new StickerAlbumData { UserId = userId };
                Albums[userId] = album;
            }

            var maxSlots = config?.TotalStickerSlots ?? 20;
            if (album.Stickers.Count < maxSlots)
                album.Stickers.Add(sticker);

            album.LastUpdated = DateTime.UtcNow;
        }

        _logger.LogInformation(
            "[StickerAlbum] User {UserId} earned [{Rarity}] sticker '{Name}'",
            userId, rarity, sticker.Name);

        return Ok(sticker);
    }

    // ─── GET /api/plugins/stickeralbum/config ───────────────────────────────

    /// <summary>Returns the current plugin configuration (read-only).</summary>
    [HttpGet("config")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ActionResult<object> GetConfig()
    {
        var cfg = Plugin.Instance?.Configuration;
        return Ok(new
        {
            watchDurationMinutes = cfg?.WatchDurationMinutes ?? 15,
            totalStickerSlots    = cfg?.TotalStickerSlots    ?? 20,
            enableSoundEffects   = cfg?.EnableSoundEffects   ?? true,
            legendaryProbability = cfg?.LegendaryProbability ?? 0.02,
            epicProbability      = cfg?.EpicProbability      ?? 0.08,
            premiumProbability   = cfg?.PremiumProbability   ?? 0.30
        });
    }

    // ─── DELETE /api/plugins/stickeralbum/album/{userId} ────────────────────

    /// <summary>Resets the sticker album for the given user.</summary>
    [HttpDelete("album/{userId}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public IActionResult ResetAlbum(string userId)
    {
        lock (Lock)
        {
            Albums.Remove(userId);
        }

        _logger.LogInformation("[StickerAlbum] Reset album for user {UserId}", userId);
        return NoContent();
    }
}
